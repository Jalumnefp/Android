package es.jfp.myapplication.login

data class User(var username: String, var password: String)
